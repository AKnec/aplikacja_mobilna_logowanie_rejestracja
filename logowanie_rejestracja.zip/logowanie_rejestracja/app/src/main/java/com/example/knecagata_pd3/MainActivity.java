package com.example.knecagata_pd3;

import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    List<String> wyniki;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = (ListView)findViewById(R.id.list);
        wyniki = new ArrayList<String>();
        SQLiteDatabase db = openOrCreateDatabase("Users", MODE_PRIVATE, null);
        try {
            Cursor c = db.rawQuery("SELECT Imie, Nazwisko, Telefon, Data FROM PEOPLE", null);
            if (c.moveToFirst()) {
                do {
                    @SuppressLint("Range") String imie = c.getString(c.getColumnIndex("Imie"));
                    @SuppressLint("Range") String nazwisko = c.getString(c.getColumnIndex("Nazwisko"));
                    @SuppressLint("Range") String data = c.getString(c.getColumnIndex("Data"));
                    wyniki.add(imie + ", " + nazwisko + " (" + data + ")");
                } while (c.moveToNext());
            }
            c.close();
            String[] strArr = new String[wyniki.size()];
            wyniki.toArray(strArr);
            ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, wyniki);
            listView.setAdapter(adapter);
        } catch (Exception e){
        }
        }

    public void onClick(View view){
        Intent myIntent = new Intent(this, MainActivity2.class);
        startActivity(myIntent);
        finish();
    }
}