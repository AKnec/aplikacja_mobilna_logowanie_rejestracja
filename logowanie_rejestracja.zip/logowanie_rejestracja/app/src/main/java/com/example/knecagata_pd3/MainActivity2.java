package com.example.knecagata_pd3;

import androidx.appcompat.app.AppCompatActivity;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class MainActivity2 extends AppCompatActivity {

    EditText urodziny;
    SQLiteDatabase db;
    final Calendar myCalendar= Calendar.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        urodziny = (EditText) findViewById(R.id.editTextDate);
        DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int day) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH,month);
                myCalendar.set(Calendar.DAY_OF_MONTH,day);
                updateLabel();
            }
        };
        urodziny.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new DatePickerDialog(MainActivity2.this, date, myCalendar.get(Calendar.YEAR), myCalendar.get(Calendar.MONTH), myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });
        }

    private void updateLabel(){
        String myFormat = "MM/dd/yyyy";
        SimpleDateFormat dateFormat = new SimpleDateFormat(myFormat, Locale.US);
        urodziny.setText(dateFormat.format(myCalendar.getTime()));
    }

    public void onClick(View view){
        db = openOrCreateDatabase("Users", MODE_PRIVATE, null);
        String sqlDB = "CREATE TABLE IF NOT EXISTS PEOPLE (Imie VARCHAR, Nazwisko VARCHAR, Telefon INTEGER, Data VARCHAR)";
        db.execSQL(sqlDB);
        String sqlPerson = "INSERT INTO PEOPLE VALUES (?, ?, ?, ?)";
        SQLiteStatement statement = db.compileStatement(sqlPerson);
        try {
            EditText imieID = (EditText) findViewById(R.id.editTextTextPersonName5);
            String imie_value = imieID.getText().toString();
            statement.bindString(1, imie_value);

            EditText nazwiskoID = (EditText) findViewById(R.id.editTextTextPersonName4);
            String nazwisko_value = nazwiskoID.getText().toString();
            statement.bindString(2, nazwisko_value);

            EditText telefonID = (EditText) findViewById(R.id.editTextPhone);
            Integer telefon_value = Integer.parseInt(String.valueOf(telefonID.getText()));
            statement.bindLong(3, telefon_value);

            EditText urodzinyID = (EditText) findViewById(R.id.editTextDate);
            String urodziny_value = urodzinyID.getText().toString();
            urodziny_value = urodziny_value.substring(6);

            statement.bindString(4, urodziny_value);
            statement.executeInsert();

            Intent myIntent = new Intent(this, MainActivity.class);
            startActivity(myIntent);
            finish();
        } catch (Exception e){
            Toast.makeText(this, "Pola są puste - dane nie są poprawne!", Toast.LENGTH_SHORT).show();
        }
    }
}